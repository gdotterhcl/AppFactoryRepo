#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIWebKitModules(JSContext* context);
JSValue* extractNFIWebKitStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIWebKitStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
