#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_NSAttributedString_symbols(JSContext*);
@protocol NSAttributedStringNSAttributedStringWebKitAdditionsCategoryInstanceExports<JSExport>
@end
@protocol NSAttributedStringNSAttributedStringWebKitAdditionsCategoryClassExports<JSExport>
JSExportAs(loadFromHTMLWithDataOptionsCompletionHandler,
+(void) jsloadFromHTMLWithData: (NSData *) data options: (NSDictionary *) options completionHandler: (JSValue *) completionHandler );
JSExportAs(loadFromHTMLWithRequestOptionsCompletionHandler,
+(void) jsloadFromHTMLWithRequest: (NSURLRequest *) request options: (NSDictionary *) options completionHandler: (JSValue *) completionHandler );
JSExportAs(loadFromHTMLWithStringOptionsCompletionHandler,
+(void) jsloadFromHTMLWithString: (NSString *) string options: (NSDictionary *) options completionHandler: (JSValue *) completionHandler );
JSExportAs(loadFromHTMLWithFileURLOptionsCompletionHandler,
+(void) jsloadFromHTMLWithFileURL: (NSURL *) fileURL options: (NSDictionary *) options completionHandler: (JSValue *) completionHandler );
@end
#pragma clang diagnostic pop