#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKUserScript_symbols(JSContext*);
@protocol WKUserScriptInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (readonly,copy,nonatomic) NSString * source;
@property (getter=isForMainFrameOnly,readonly,nonatomic) BOOL forMainFrameOnly;
@property (readonly,nonatomic) WKUserScriptInjectionTime injectionTime;
JSExportAs(initWithSourceInjectionTimeForMainFrameOnly,
-(id) jsinitWithSource: (NSString *) source injectionTime: (WKUserScriptInjectionTime) injectionTime forMainFrameOnly: (BOOL) forMainFrameOnly );
JSExportAs(initWithSourceInjectionTimeForMainFrameOnlyInContentWorld,
-(id) jsinitWithSource: (NSString *) source injectionTime: (WKUserScriptInjectionTime) injectionTime forMainFrameOnly: (BOOL) forMainFrameOnly inContentWorld: (WKContentWorld *) contentWorld );
@end
@protocol WKUserScriptClassExports<JSExport, NSCopyingClassExports_>
@end
#pragma clang diagnostic pop