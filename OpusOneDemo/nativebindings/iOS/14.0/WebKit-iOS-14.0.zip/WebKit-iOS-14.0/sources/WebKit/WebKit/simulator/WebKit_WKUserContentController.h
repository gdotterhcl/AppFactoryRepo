#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKUserContentController_symbols(JSContext*);
@protocol WKUserContentControllerInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (readonly,copy,nonatomic) NSArray * userScripts;
-(void) removeAllContentRuleLists;
-(void) removeAllScriptMessageHandlersFromContentWorld: (WKContentWorld *) contentWorld ;
-(void) removeAllUserScripts;
-(void) removeScriptMessageHandlerForName: (NSString *) name ;
-(void) addUserScript: (WKUserScript *) userScript ;
-(void) addScriptMessageHandlerWithReply: (id) scriptMessageHandlerWithReply contentWorld: (WKContentWorld *) contentWorld name: (NSString *) name ;
-(void) removeScriptMessageHandlerForName: (NSString *) name contentWorld: (WKContentWorld *) contentWorld ;
-(void) addScriptMessageHandler: (id) scriptMessageHandler contentWorld: (WKContentWorld *) world name: (NSString *) name ;
-(void) removeAllScriptMessageHandlers;
-(void) addScriptMessageHandler: (id) scriptMessageHandler name: (NSString *) name ;
-(void) addContentRuleList: (WKContentRuleList *) contentRuleList ;
-(void) removeContentRuleList: (WKContentRuleList *) contentRuleList ;
@end
@protocol WKUserContentControllerClassExports<JSExport, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop