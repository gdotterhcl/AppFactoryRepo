#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKURLSchemeTask_symbols(JSContext*);
@protocol WKURLSchemeTaskInstanceExports_<JSExport, NSObjectInstanceExports_>
@property (readonly,copy,nonatomic) NSURLRequest * request;
-(void) didReceiveResponse: (NSURLResponse *) response ;
-(void) didFinish;
-(void) didFailWithError: (NSError *) error ;
-(void) didReceiveData: (NSData *) data ;
@end
@protocol WKURLSchemeTaskClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop