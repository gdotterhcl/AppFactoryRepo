#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKPreferences_symbols(JSContext*);
@protocol WKPreferencesWKDeprecatedCategoryInstanceExports<JSExport>
@property (nonatomic) BOOL javaScriptEnabled;
@end
@protocol WKPreferencesWKDeprecatedCategoryClassExports<JSExport>
@end
@protocol WKPreferencesInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (getter=isFraudulentWebsiteWarningEnabled,nonatomic) BOOL fraudulentWebsiteWarningEnabled;
@property (nonatomic) BOOL javaScriptCanOpenWindowsAutomatically;
@property (nonatomic) CGFloat minimumFontSize;
@end
@protocol WKPreferencesClassExports<JSExport, NSSecureCodingClassExports_>
@end
#pragma clang diagnostic pop