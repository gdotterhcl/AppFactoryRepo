#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKBackForwardList_symbols(JSContext*);
@protocol WKBackForwardListInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSArray * backList;
@property (readonly,nonatomic,strong) WKBackForwardListItem * currentItem;
@property (readonly,copy,nonatomic) NSArray * forwardList;
@property (readonly,nonatomic,strong) WKBackForwardListItem * backItem;
@property (readonly,nonatomic,strong) WKBackForwardListItem * forwardItem;
-(WKBackForwardListItem *) itemAtIndex: (NSInteger) index ;
@end
@protocol WKBackForwardListClassExports<JSExport>
@end
#pragma clang diagnostic pop