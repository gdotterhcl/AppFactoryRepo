#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKScriptMessageHandler_symbols(JSContext*);
@protocol WKScriptMessageHandlerInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) userContentController: (WKUserContentController *) userContentController didReceiveScriptMessage: (WKScriptMessage *) message ;
@end
@protocol WKScriptMessageHandlerClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop