#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKUIDelegate_symbols(JSContext*);
@protocol WKUIDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) webView: (WKWebView *) webView contextMenuForElement: (WKContextMenuElementInfo *) elementInfo willCommitWithAnimator: (id) animator ;
JSExportAs(webViewContextMenuConfigurationForElementCompletionHandler,
-(void) jswebView: (WKWebView *) webView contextMenuConfigurationForElement: (WKContextMenuElementInfo *) elementInfo completionHandler: (JSValue *) completionHandler );
-(void) webView: (WKWebView *) webView contextMenuDidEndForElement: (WKContextMenuElementInfo *) elementInfo ;
-(WKWebView *) webView: (WKWebView *) webView createWebViewWithConfiguration: (WKWebViewConfiguration *) configuration forNavigationAction: (WKNavigationAction *) navigationAction windowFeatures: (WKWindowFeatures *) windowFeatures ;
JSExportAs(webViewRunJavaScriptTextInputPanelWithPromptDefaultTextInitiatedByFrameCompletionHandler,
-(void) jswebView: (WKWebView *) webView runJavaScriptTextInputPanelWithPrompt: (NSString *) prompt defaultText: (NSString *) defaultText initiatedByFrame: (WKFrameInfo *) frame completionHandler: (JSValue *) completionHandler );
JSExportAs(webViewRunJavaScriptConfirmPanelWithMessageInitiatedByFrameCompletionHandler,
-(void) jswebView: (WKWebView *) webView runJavaScriptConfirmPanelWithMessage: (NSString *) message initiatedByFrame: (WKFrameInfo *) frame completionHandler: (JSValue *) completionHandler );
-(void) webView: (WKWebView *) webView contextMenuWillPresentForElement: (WKContextMenuElementInfo *) elementInfo ;
JSExportAs(webViewRunJavaScriptAlertPanelWithMessageInitiatedByFrameCompletionHandler,
-(void) jswebView: (WKWebView *) webView runJavaScriptAlertPanelWithMessage: (NSString *) message initiatedByFrame: (WKFrameInfo *) frame completionHandler: (JSValue *) completionHandler );
-(UIViewController *) webView: (WKWebView *) webView previewingViewControllerForElement: (WKPreviewElementInfo *) elementInfo defaultActions: (NSArray *) previewActions ;
-(void) webViewDidClose: (WKWebView *) webView ;
-(void) webView: (WKWebView *) webView commitPreviewingViewController: (UIViewController *) previewingViewController ;
-(BOOL) webView: (WKWebView *) webView shouldPreviewElement: (WKPreviewElementInfo *) elementInfo ;
@end
@protocol WKUIDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop