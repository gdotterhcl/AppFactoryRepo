#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKContentRuleListStore_symbols(JSContext*);
@protocol WKContentRuleListStoreInstanceExports<JSExport>
JSExportAs(lookUpContentRuleListForIdentifierCompletionHandler,
-(void) jslookUpContentRuleListForIdentifier: (NSString *) identifier completionHandler: (JSValue *) completionHandler );
JSExportAs(getAvailableContentRuleListIdentifiers,
-(void) jsgetAvailableContentRuleListIdentifiers: (JSValue *) completionHandler );
JSExportAs(compileContentRuleListForIdentifierEncodedContentRuleListCompletionHandler,
-(void) jscompileContentRuleListForIdentifier: (NSString *) identifier encodedContentRuleList: (NSString *) encodedContentRuleList completionHandler: (JSValue *) completionHandler );
JSExportAs(removeContentRuleListForIdentifierCompletionHandler,
-(void) jsremoveContentRuleListForIdentifier: (NSString *) identifier completionHandler: (JSValue *) completionHandler );
@end
@protocol WKContentRuleListStoreClassExports<JSExport>
+(id) storeWithURL: (NSURL *) url ;
+(id) defaultStore;
@end
#pragma clang diagnostic pop