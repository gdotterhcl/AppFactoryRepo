#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKSnapshotConfiguration_symbols(JSContext*);
@protocol WKSnapshotConfigurationInstanceExports<JSExport, NSCopyingInstanceExports_>
@property (nonatomic) BOOL afterScreenUpdates;
@property (copy,nonatomic) NSNumber * snapshotWidth;
@property (nonatomic) CGRect rect;
@end
@protocol WKSnapshotConfigurationClassExports<JSExport, NSCopyingClassExports_>
@end
#pragma clang diagnostic pop