#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKWebsiteDataStore_symbols(JSContext*);
@protocol WKWebsiteDataStoreInstanceExports<JSExport, NSSecureCodingInstanceExports_>
@property (readonly,nonatomic) WKHTTPCookieStore * httpCookieStore;
@property (getter=isPersistent,readonly,nonatomic) BOOL persistent;
JSExportAs(fetchDataRecordsOfTypesCompletionHandler,
-(void) jsfetchDataRecordsOfTypes: (NSSet *) dataTypes completionHandler: (JSValue *) completionHandler );
JSExportAs(removeDataOfTypesForDataRecordsCompletionHandler,
-(void) jsremoveDataOfTypes: (NSSet *) dataTypes forDataRecords: (NSArray *) dataRecords completionHandler: (JSValue *) completionHandler );
JSExportAs(removeDataOfTypesModifiedSinceCompletionHandler,
-(void) jsremoveDataOfTypes: (NSSet *) dataTypes modifiedSince: (NSDate *) date completionHandler: (JSValue *) completionHandler );
@end
@protocol WKWebsiteDataStoreClassExports<JSExport, NSSecureCodingClassExports_>
+(NSSet *) allWebsiteDataTypes;
+(WKWebsiteDataStore *) defaultDataStore;
+(WKWebsiteDataStore *) nonPersistentDataStore;
@end
#pragma clang diagnostic pop