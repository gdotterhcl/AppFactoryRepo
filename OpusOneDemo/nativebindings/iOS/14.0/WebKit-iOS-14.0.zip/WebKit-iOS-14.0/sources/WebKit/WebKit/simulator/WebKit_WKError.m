#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"WKErrorUnknown"] = @1L;
	context[@"WKErrorWebContentProcessTerminated"] = @2L;
	context[@"WKErrorWebViewInvalidated"] = @3L;
	context[@"WKErrorJavaScriptExceptionOccurred"] = @4L;
	context[@"WKErrorJavaScriptResultTypeIsUnsupported"] = @5L;
	context[@"WKErrorContentRuleListStoreCompileFailed"] = @6L;
	context[@"WKErrorContentRuleListStoreLookUpFailed"] = @7L;
	context[@"WKErrorContentRuleListStoreRemoveFailed"] = @8L;
	context[@"WKErrorContentRuleListStoreVersionMismatch"] = @9L;
	context[@"WKErrorAttributedStringContentFailedToLoad"] = @10L;
	context[@"WKErrorAttributedStringContentLoadTimedOut"] = @11L;
	context[@"WKErrorJavaScriptInvalidFrameTarget"] = @12L;
	context[@"WKErrorNavigationAppBoundDomain"] = @13L;
	context[@"WKErrorJavaScriptAppBoundDomain"] = @14L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &WKErrorDomain;
	if (p != NULL) context[@"WKErrorDomain"] = WKErrorDomain;
}
void load_WebKit_WKError_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
