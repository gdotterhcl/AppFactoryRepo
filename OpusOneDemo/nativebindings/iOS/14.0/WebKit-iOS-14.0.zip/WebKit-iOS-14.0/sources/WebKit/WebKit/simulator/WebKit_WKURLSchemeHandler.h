#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKURLSchemeHandler_symbols(JSContext*);
@protocol WKURLSchemeHandlerInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) webView: (WKWebView *) webView startURLSchemeTask: (id) urlSchemeTask ;
-(void) webView: (WKWebView *) webView stopURLSchemeTask: (id) urlSchemeTask ;
@end
@protocol WKURLSchemeHandlerClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop