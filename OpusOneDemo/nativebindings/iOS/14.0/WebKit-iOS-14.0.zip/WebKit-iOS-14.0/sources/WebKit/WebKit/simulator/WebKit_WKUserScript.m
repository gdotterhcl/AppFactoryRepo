#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation WKUserScript (Exports)
-(id) jsinitWithSource: (NSString *) source injectionTime: (WKUserScriptInjectionTime) injectionTime forMainFrameOnly: (BOOL) forMainFrameOnly 
{
	id resultVal__;
	resultVal__ = [[self initWithSource: source injectionTime: injectionTime forMainFrameOnly: forMainFrameOnly ] autorelease];
	return resultVal__;
}
-(id) jsinitWithSource: (NSString *) source injectionTime: (WKUserScriptInjectionTime) injectionTime forMainFrameOnly: (BOOL) forMainFrameOnly inContentWorld: (WKContentWorld *) contentWorld 
{
	id resultVal__;
	resultVal__ = [[self initWithSource: source injectionTime: injectionTime forMainFrameOnly: forMainFrameOnly inContentWorld: contentWorld ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([WKUserScript class], @protocol(WKUserScriptInstanceExports));
	class_addProtocol([WKUserScript class], @protocol(WKUserScriptClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"WKUserScriptInjectionTimeAtDocumentStart"] = @0L;
	context[@"WKUserScriptInjectionTimeAtDocumentEnd"] = @1L;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_WebKit_WKUserScript_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
