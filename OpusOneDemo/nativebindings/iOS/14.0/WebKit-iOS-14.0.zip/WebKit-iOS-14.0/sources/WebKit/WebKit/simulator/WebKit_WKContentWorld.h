#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKContentWorld_symbols(JSContext*);
@protocol WKContentWorldInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSString * name;
@end
@protocol WKContentWorldClassExports<JSExport>
+(WKContentWorld *) pageWorld;
+(WKContentWorld *) worldWithName: (NSString *) name ;
+(WKContentWorld *) defaultClientWorld;
@end
#pragma clang diagnostic pop