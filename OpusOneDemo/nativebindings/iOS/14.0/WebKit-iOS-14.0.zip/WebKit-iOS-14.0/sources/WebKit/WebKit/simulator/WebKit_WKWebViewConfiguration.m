#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation WKWebViewConfiguration (Exports)
-(id) jsinitWithCoder: (NSCoder *) coder 
{
	id resultVal__;
	resultVal__ = [[self initWithCoder: coder ] autorelease];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([WKWebViewConfiguration class], @protocol(WKWebViewConfigurationInstanceExports));
	class_addProtocol([WKWebViewConfiguration class], @protocol(WKWebViewConfigurationClassExports));
	class_addProtocol([WKWebViewConfiguration class], @protocol(WKWebViewConfigurationWKDeprecatedCategoryInstanceExports));
	class_addProtocol([WKWebViewConfiguration class], @protocol(WKWebViewConfigurationWKDeprecatedCategoryClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
	context[@"WKSelectionGranularityDynamic"] = @0L;
	context[@"WKSelectionGranularityCharacter"] = @1L;

	context[@"WKAudiovisualMediaTypeNone"] = @0UL;
	context[@"WKAudiovisualMediaTypeAudio"] = @1UL;
	context[@"WKAudiovisualMediaTypeVideo"] = @2UL;
	context[@"WKAudiovisualMediaTypeAll"] = @-1UL;

}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_WebKit_WKWebViewConfiguration_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
