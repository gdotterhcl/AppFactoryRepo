#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKWebViewConfiguration_symbols(JSContext*);
@protocol WKWebViewConfigurationInstanceExports<JSExport, NSSecureCodingInstanceExports_, NSCopyingInstanceExports_>
@property (nonatomic) BOOL allowsAirPlayForMediaPlayback;
@property (nonatomic,strong) WKPreferences * preferences;
@property (copy,nonatomic) WKWebpagePreferences * defaultWebpagePreferences;
@property (nonatomic) BOOL allowsPictureInPictureMediaPlayback;
@property (nonatomic) WKDataDetectorTypes dataDetectorTypes;
@property (nonatomic,strong) WKProcessPool * processPool;
@property (copy,nonatomic) NSString * applicationNameForUserAgent;
@property (nonatomic) WKSelectionGranularity selectionGranularity;
@property (nonatomic) BOOL suppressesIncrementalRendering;
@property (nonatomic,strong) WKUserContentController * userContentController;
@property (nonatomic,strong) WKWebsiteDataStore * websiteDataStore;
@property (nonatomic) WKAudiovisualMediaTypes mediaTypesRequiringUserActionForPlayback;
@property (nonatomic) BOOL ignoresViewportScaleLimits;
@property (nonatomic) BOOL limitsNavigationsToAppBoundDomains;
@property (nonatomic) BOOL allowsInlineMediaPlayback;
-(id) urlSchemeHandlerForURLScheme: (NSString *) urlScheme ;
-(void) setURLSchemeHandler: (id) urlSchemeHandler forURLScheme: (NSString *) urlScheme ;
@end
@protocol WKWebViewConfigurationClassExports<JSExport, NSSecureCodingClassExports_, NSCopyingClassExports_>
@end
@protocol WKWebViewConfigurationWKDeprecatedCategoryInstanceExports<JSExport>
@property (nonatomic) BOOL mediaPlaybackAllowsAirPlay;
@property (nonatomic) BOOL requiresUserActionForMediaPlayback;
@property (nonatomic) BOOL mediaPlaybackRequiresUserAction;
@end
@protocol WKWebViewConfigurationWKDeprecatedCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop