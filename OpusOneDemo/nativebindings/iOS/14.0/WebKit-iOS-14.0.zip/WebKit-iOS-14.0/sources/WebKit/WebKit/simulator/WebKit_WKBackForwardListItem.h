#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKBackForwardListItem_symbols(JSContext*);
@protocol WKBackForwardListItemInstanceExports<JSExport>
@property (readonly,copy) NSURL * URL;
@property (readonly,copy) NSURL * initialURL;
@property (readonly,copy) NSString * title;
@end
@protocol WKBackForwardListItemClassExports<JSExport>
@end
#pragma clang diagnostic pop