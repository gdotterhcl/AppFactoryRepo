#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKWebpagePreferences_symbols(JSContext*);
@protocol WKWebpagePreferencesInstanceExports<JSExport>
@property (nonatomic) BOOL allowsContentJavaScript;
@property (nonatomic) WKContentMode preferredContentMode;
@end
@protocol WKWebpagePreferencesClassExports<JSExport>
@end
#pragma clang diagnostic pop