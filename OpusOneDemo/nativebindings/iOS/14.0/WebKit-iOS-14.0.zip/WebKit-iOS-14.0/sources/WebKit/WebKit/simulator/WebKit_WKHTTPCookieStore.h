#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_WebKit_WKHTTPCookieStore_symbols(JSContext*);
@protocol WKHTTPCookieStoreInstanceExports<JSExport>
JSExportAs(deleteCookieCompletionHandler,
-(void) jsdeleteCookie: (NSHTTPCookie *) cookie completionHandler: (JSValue *) completionHandler );
JSExportAs(getAllCookies,
-(void) jsgetAllCookies: (JSValue *) completionHandler );
-(void) addObserver: (id) observer ;
JSExportAs(setCookieCompletionHandler,
-(void) jssetCookie: (NSHTTPCookie *) cookie completionHandler: (JSValue *) completionHandler );
-(void) removeObserver: (id) observer ;
@end
@protocol WKHTTPCookieStoreClassExports<JSExport>
@end
@protocol WKHTTPCookieStoreObserverInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) cookiesDidChangeInCookieStore: (WKHTTPCookieStore *) cookieStore ;
@end
@protocol WKHTTPCookieStoreObserverClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop