#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UIKit_UISearchController_symbols(JSContext*);
@protocol UISearchControllerInstanceExports<JSExport, UIViewControllerTransitioningDelegateInstanceExports_, UIViewControllerAnimatedTransitioningInstanceExports_>
@property (nonatomic) BOOL automaticallyShowsSearchResultsController;
@property (assign,nonatomic) BOOL hidesNavigationBarDuringPresentation;
@property (assign,nonatomic) BOOL obscuresBackgroundDuringPresentation;
@property (nonatomic,weak) id searchResultsUpdater;
@property (nonatomic) BOOL showsSearchResultsController;
@property (nonatomic) BOOL automaticallyShowsScopeBar;
@property (nonatomic) BOOL automaticallyShowsCancelButton;
@property (nonatomic,weak) id delegate;
@property (getter=isActive,assign,nonatomic) BOOL active;
@property (readonly,nonatomic,strong) UIViewController * searchResultsController;
@property (assign,nonatomic) BOOL dimsBackgroundDuringPresentation;
@property (readonly,nonatomic,strong) UISearchBar * searchBar;
JSExportAs(initWithNibNameBundle,
-(id) jsinitWithNibName: (NSString *) nibNameOrNil bundle: (NSBundle *) nibBundleOrNil );
JSExportAs(initWithSearchResultsController,
-(id) jsinitWithSearchResultsController: (UIViewController *) searchResultsController );
JSExportAs(initWithCoder,
-(id) jsinitWithCoder: (NSCoder *) coder );
@end
@protocol UISearchControllerClassExports<JSExport, UIViewControllerTransitioningDelegateClassExports_, UIViewControllerAnimatedTransitioningClassExports_>
@end
@protocol UISearchControllerDelegateInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) presentSearchController: (UISearchController *) searchController ;
-(void) willDismissSearchController: (UISearchController *) searchController ;
-(void) willPresentSearchController: (UISearchController *) searchController ;
-(void) didDismissSearchController: (UISearchController *) searchController ;
-(void) didPresentSearchController: (UISearchController *) searchController ;
@end
@protocol UISearchControllerDelegateClassExports_<JSExport, NSObjectClassExports_>
@end
@protocol UISearchResultsUpdatingInstanceExports_<JSExport, NSObjectInstanceExports_>
-(void) updateSearchResultsForSearchController: (UISearchController *) searchController ;
@end
@protocol UISearchResultsUpdatingClassExports_<JSExport, NSObjectClassExports_>
@end
#pragma clang diagnostic pop