#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
static void addProtocols()
{
	class_addProtocol([WKWebsiteDataRecord class], @protocol(WKWebsiteDataRecordInstanceExports));
	class_addProtocol([WKWebsiteDataRecord class], @protocol(WKWebsiteDataRecordClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
	p = (void*) &WKWebsiteDataTypeIndexedDBDatabases;
	if (p != NULL) context[@"WKWebsiteDataTypeIndexedDBDatabases"] = WKWebsiteDataTypeIndexedDBDatabases;
	p = (void*) &WKWebsiteDataTypeFetchCache;
	if (p != NULL) context[@"WKWebsiteDataTypeFetchCache"] = WKWebsiteDataTypeFetchCache;
	p = (void*) &WKWebsiteDataTypeLocalStorage;
	if (p != NULL) context[@"WKWebsiteDataTypeLocalStorage"] = WKWebsiteDataTypeLocalStorage;
	p = (void*) &WKWebsiteDataTypeServiceWorkerRegistrations;
	if (p != NULL) context[@"WKWebsiteDataTypeServiceWorkerRegistrations"] = WKWebsiteDataTypeServiceWorkerRegistrations;
	p = (void*) &WKWebsiteDataTypeMemoryCache;
	if (p != NULL) context[@"WKWebsiteDataTypeMemoryCache"] = WKWebsiteDataTypeMemoryCache;
	p = (void*) &WKWebsiteDataTypeDiskCache;
	if (p != NULL) context[@"WKWebsiteDataTypeDiskCache"] = WKWebsiteDataTypeDiskCache;
	p = (void*) &WKWebsiteDataTypeCookies;
	if (p != NULL) context[@"WKWebsiteDataTypeCookies"] = WKWebsiteDataTypeCookies;
	p = (void*) &WKWebsiteDataTypeWebSQLDatabases;
	if (p != NULL) context[@"WKWebsiteDataTypeWebSQLDatabases"] = WKWebsiteDataTypeWebSQLDatabases;
	p = (void*) &WKWebsiteDataTypeOfflineWebApplicationCache;
	if (p != NULL) context[@"WKWebsiteDataTypeOfflineWebApplicationCache"] = WKWebsiteDataTypeOfflineWebApplicationCache;
	p = (void*) &WKWebsiteDataTypeSessionStorage;
	if (p != NULL) context[@"WKWebsiteDataTypeSessionStorage"] = WKWebsiteDataTypeSessionStorage;
}
void load_WebKit_WKWebsiteDataRecord_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
