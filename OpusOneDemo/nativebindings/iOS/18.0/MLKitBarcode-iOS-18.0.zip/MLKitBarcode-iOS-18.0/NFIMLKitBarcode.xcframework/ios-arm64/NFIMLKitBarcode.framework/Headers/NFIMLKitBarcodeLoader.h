#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIMLKitBarcodeModules(JSContext* context);
JSValue* extractNFIMLKitBarcodeStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIMLKitBarcodeStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
