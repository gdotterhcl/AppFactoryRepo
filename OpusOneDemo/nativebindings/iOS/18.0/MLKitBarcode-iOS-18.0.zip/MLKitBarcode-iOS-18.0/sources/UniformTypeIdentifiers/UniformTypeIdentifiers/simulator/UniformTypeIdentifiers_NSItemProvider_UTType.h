#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UniformTypeIdentifiers_NSItemProvider_UTType_symbols(JSContext*);
@protocol NSItemProviderUTTypeCategoryInstanceExports<JSExport>
@property (readonly,copy,nonatomic) NSArray * registeredContentTypes;
@property (readonly,copy,nonatomic) NSArray * registeredContentTypesForOpenInPlace;
JSExportAs(initWithContentsOfURLContentTypeOpenInPlaceCoordinatedVisibility,
-(id) jsinitWithContentsOfURL: (NSURL *) fileURL contentType: (UTType *) contentType openInPlace: (BOOL) openInPlace coordinated: (BOOL) coordinated visibility: (NSItemProviderRepresentationVisibility) visibility );
JSExportAs(registerDataRepresentationForContentTypeVisibilityLoadHandler,
-(void) jsregisterDataRepresentationForContentType: (UTType *) contentType visibility: (NSItemProviderRepresentationVisibility) visibility loadHandler: (JSValue *) loadHandler );
JSExportAs(registerFileRepresentationForContentTypeVisibilityOpenInPlaceLoadHandler,
-(void) jsregisterFileRepresentationForContentType: (UTType *) contentType visibility: (NSItemProviderRepresentationVisibility) visibility openInPlace: (BOOL) openInPlace loadHandler: (JSValue *) loadHandler );
-(NSArray *) registeredContentTypesConformingToContentType: (UTType *) contentType ;
JSExportAs(loadDataRepresentationForContentTypeCompletionHandler,
-(NSProgress *) jsloadDataRepresentationForContentType: (UTType *) contentType completionHandler: (JSValue *) completionHandler );
JSExportAs(loadFileRepresentationForContentTypeOpenInPlaceCompletionHandler,
-(NSProgress *) jsloadFileRepresentationForContentType: (UTType *) contentType openInPlace: (BOOL) openInPlace completionHandler: (JSValue *) completionHandler );
@end
@protocol NSItemProviderUTTypeCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop