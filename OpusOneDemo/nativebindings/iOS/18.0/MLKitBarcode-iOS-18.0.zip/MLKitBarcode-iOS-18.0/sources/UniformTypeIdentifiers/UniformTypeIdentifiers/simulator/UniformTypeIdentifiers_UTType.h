#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_UniformTypeIdentifiers_UTType_symbols(JSContext*);
@protocol UTTypeInstanceExports<JSExport, NSCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly) NSString * identifier;
@property (readonly) NSString * preferredFilenameExtension;
@property (readonly) NSString * preferredMIMEType;
@property (readonly) NSString * localizedDescription;
@property (readonly) NSNumber * version;
@property (readonly) NSURL * referenceURL;
@property (getter=isDynamic,readonly) BOOL dynamic;
@property (getter=isDeclared,readonly) BOOL declared;
@property (getter=isPublicType,readonly) BOOL publicType;
@end
@protocol UTTypeClassExports<JSExport, NSCopyingClassExports_, NSSecureCodingClassExports_>
+(id) typeWithIdentifier: (NSString *) identifier ;
+(id) typeWithFilenameExtension: (NSString *) filenameExtension ;
+(id) typeWithFilenameExtension: (NSString *) filenameExtension conformingToType: (UTType *) supertype ;
+(id) typeWithMIMEType: (NSString *) mimeType ;
+(id) typeWithMIMEType: (NSString *) mimeType conformingToType: (UTType *) supertype ;
@end
@protocol UTTypeConformanceCategoryInstanceExports<JSExport>
@property (readonly) NSSet * supertypes;
-(BOOL) conformsToType: (UTType *) type ;
-(BOOL) isSupertypeOfType: (UTType *) type ;
-(BOOL) isSubtypeOfType: (UTType *) type ;
@end
@protocol UTTypeConformanceCategoryClassExports<JSExport>
@end
@protocol UTTypeUTTagSpecificationCategoryInstanceExports<JSExport>
@property (readonly) NSDictionary * tags;
@end
@protocol UTTypeUTTagSpecificationCategoryClassExports<JSExport>
+(id) typeWithTag: (NSString *) tag tagClass: (NSString *) tagClass conformingToType: (UTType *) supertype ;
+(NSArray *) typesWithTag: (NSString *) tag tagClass: (NSString *) tagClass conformingToType: (UTType *) supertype ;
@end
@protocol UTTypeLocalConstantsCategoryInstanceExports<JSExport>
@end
@protocol UTTypeLocalConstantsCategoryClassExports<JSExport>
+(UTType *) exportedTypeWithIdentifier: (NSString *) identifier ;
+(UTType *) exportedTypeWithIdentifier: (NSString *) identifier conformingToType: (UTType *) parentType ;
+(UTType *) importedTypeWithIdentifier: (NSString *) identifier ;
+(UTType *) importedTypeWithIdentifier: (NSString *) identifier conformingToType: (UTType *) parentType ;
@end
#pragma clang diagnostic pop