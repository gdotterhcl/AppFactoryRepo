#import <objc/runtime.h>
#import "allincludes.h"
#import <NFIUtility/CallbackSupport.h>
#import <NFIUtility/PointerSupport.h>
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat-security"
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wincompatible-pointer-types"
#pragma clang diagnostic ignored "-Wnullability-completeness"
@implementation NSItemProvider (NSItemProviderUTTypeCategoryExports)
-(id) jsinitWithContentsOfURL: (NSURL *) fileURL contentType: (UTType *) contentType openInPlace: (BOOL) openInPlace coordinated: (BOOL) coordinated visibility: (NSItemProviderRepresentationVisibility) visibility 
{
	id resultVal__;
	resultVal__ = [[self initWithContentsOfURL: fileURL contentType: contentType openInPlace: openInPlace coordinated: coordinated visibility: visibility ] autorelease];
	return resultVal__;
}
-(void) jsregisterDataRepresentationForContentType: (UTType *) contentType visibility: (NSItemProviderRepresentationVisibility) visibility loadHandler: (JSValue *) loadHandler 
{
	NSProgress *  (^ loadHandler_)(void (^ loadHandler_ )(NSData * , NSError * )) = nil;
	if (!loadHandler.isUndefined) {
		loadHandler_ = ^NSProgress *(void (^ arg0)(NSData * _Nullable, NSError * _Nullable)) {
			JSContext* __jsContext = loadHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			JSValue* result = callJSFunction(__jsContext, loadHandler, self, parameters);
			return [result toObject];
		};
	}
	[self registerDataRepresentationForContentType: contentType visibility: visibility loadHandler: loadHandler_ ];
}
-(void) jsregisterFileRepresentationForContentType: (UTType *) contentType visibility: (NSItemProviderRepresentationVisibility) visibility openInPlace: (BOOL) openInPlace loadHandler: (JSValue *) loadHandler 
{
	NSProgress *  (^ loadHandler_)(void (^ loadHandler_ )(NSURL * , BOOL, NSError * )) = nil;
	if (!loadHandler.isUndefined) {
		loadHandler_ = ^NSProgress *(void (^ arg0)(NSURL * _Nullable, BOOL, NSError * _Nullable)) {
			JSContext* __jsContext = loadHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			JSValue* result = callJSFunction(__jsContext, loadHandler, self, parameters);
			return [result toObject];
		};
	}
	[self registerFileRepresentationForContentType: contentType visibility: visibility openInPlace: openInPlace loadHandler: loadHandler_ ];
}
-(NSProgress *) jsloadDataRepresentationForContentType: (UTType *) contentType completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSData * , NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSData * arg0, NSError * arg1) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: (arg1 ? [JSValue valueWithObject: arg1 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	NSProgress * resultVal__;
	resultVal__ = [self loadDataRepresentationForContentType: contentType completionHandler: completionHandler_ ];
	return resultVal__;
}
-(NSProgress *) jsloadFileRepresentationForContentType: (UTType *) contentType openInPlace: (BOOL) openInPlace completionHandler: (JSValue *) completionHandler 
{
	void (^ completionHandler_)(NSURL * , BOOL, NSError * ) = nil;
	if (!completionHandler.isUndefined) {
		completionHandler_ = ^void(NSURL * arg0, BOOL arg1, NSError * arg2) {
			JSContext* __jsContext = completionHandler.context;
			NSMutableArray* parameters = [NSMutableArray array];
			[parameters addObject: (arg0 ? [JSValue valueWithObject: arg0 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			[parameters addObject: [JSValue valueWithObject: @(arg1) inContext: __jsContext]];
			[parameters addObject: (arg2 ? [JSValue valueWithObject: arg2 inContext: __jsContext] : [JSValue valueWithUndefinedInContext: __jsContext])];
			callJSFunction(__jsContext, completionHandler, self, parameters);
		};
	}
	NSProgress * resultVal__;
	resultVal__ = [self loadFileRepresentationForContentType: contentType openInPlace: openInPlace completionHandler: completionHandler_ ];
	return resultVal__;
}
@end
static void addProtocols()
{
	class_addProtocol([NSItemProvider class], @protocol(NSItemProviderUTTypeCategoryInstanceExports));
	class_addProtocol([NSItemProvider class], @protocol(NSItemProviderUTTypeCategoryClassExports));
}
static void registerCFunctions(JSContext* context)
{
}
static void registerEnumConstants(JSContext* context)
{
}
static void registerGlobalConstants(JSContext* context)
{
	void* p; p = NULL;
}
void load_UniformTypeIdentifiers_NSItemProvider_UTType_symbols(JSContext* context)
{
    addProtocols();
    registerEnumConstants(context);
    registerCFunctions(context);
    registerGlobalConstants(context);
}
#pragma clang diagnostic pop
