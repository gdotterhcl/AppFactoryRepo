#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIAVFAudioModules(JSContext* context);
JSValue* extractNFIAVFAudioStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIAVFAudioStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
